import java.io.*;
import java.net.Socket;

public class ChatClient {
    private final Socket socket;
    private final ObjectOutputStream out;
    private final ObjectInputStream in;

    public ChatClient(String host, int port) throws IOException {
        socket = new Socket(host, port);
        out = new ObjectOutputStream(socket.getOutputStream());
        out.flush();
        in = new ObjectInputStream(socket.getInputStream());
    }

    public void sendMessage(Message msg) throws IOException {
        out.writeObject(msg);
        out.flush();
    }

    public ObjectInputStream getInputStream() {
        return in;
    }

    public void close() {
        try { socket.close(); } catch (IOException ignored) {}
    }
}
