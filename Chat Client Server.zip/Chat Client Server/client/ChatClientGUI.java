import javax.swing.*;
import java.awt.*;
import java.io.ObjectInputStream;

public class ChatClientGUI extends JFrame {

    private final JTextArea chatArea = new JTextArea();
    private final JTextField inputField = new JTextField();
    private final JButton sendButton = new JButton("Trimite");

    private ChatClient client;
    private String username;

    public ChatClientGUI() {
        username = JOptionPane.showInputDialog(this, "Nume utilizator:");
        if (username == null || username.trim().isEmpty()) {
            username = "Anonim";
        }

        try {
            client = new ChatClient("localhost", 1234);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Nu mă pot conecta la server (localhost:1234).\nPornește serverul mai întâi!");
            System.exit(0);
        }

        setTitle("Chat - " + username);
        setSize(500, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        chatArea.setEditable(false);
        chatArea.setLineWrap(true);
        chatArea.setWrapStyleWord(true);

        sendButton.addActionListener(e -> send());
        inputField.addActionListener(e -> send()); // Enter

        JPanel bottom = new JPanel(new BorderLayout(8, 8));
        bottom.add(inputField, BorderLayout.CENTER);
        bottom.add(sendButton, BorderLayout.EAST);

        setLayout(new BorderLayout(8, 8));
        add(new JScrollPane(chatArea), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);

        new Thread(this::receiveMessages, "ReceiverThread").start();
    }

    private void send() {
        String text = inputField.getText().trim();
        if (text.isEmpty()) return;

        try {
            client.sendMessage(new Message(username, text));
            inputField.setText("");
        } catch (Exception ex) {
            chatArea.append("[Eroare] Nu pot trimite mesajul.\n");
        }
    }

    private void receiveMessages() {
        try {
            ObjectInputStream in = client.getInputStream();
            while (true) {
                Object obj = in.readObject();
                if (obj instanceof Message msg) {
                    SwingUtilities.invokeLater(() ->
                            chatArea.append(msg.getSender() + ": " + msg.getText() + "\n")
                    );
                }
            }
        } catch (Exception e) {
            SwingUtilities.invokeLater(() -> chatArea.append("[Info] Conexiunea s-a închis.\n"));
        } finally {
            if (client != null) client.close();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ChatClientGUI::new);
    }
}
