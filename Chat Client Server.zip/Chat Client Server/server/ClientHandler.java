import java.io.*;
import java.net.Socket;

public class ClientHandler extends Thread {
    private final Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            out = new ObjectOutputStream(socket.getOutputStream());
            out.flush();
            in = new ObjectInputStream(socket.getInputStream());

            while (true) {
                Object obj = in.readObject();
                if (obj instanceof Message msg) {
                    ChatServer.broadcast(msg);
                }
            }
        } catch (EOFException eof) {
            System.out.println("Client deconectat (EOF).");
        } catch (Exception e) {
            System.out.println("Client deconectat.");
        } finally {
            ChatServer.removeClient(this);
            try { socket.close(); } catch (IOException ignored) {}
        }
    }

    public void sendMessage(Message msg) {
        try {
            out.writeObject(msg);
            out.flush();
        } catch (IOException ignored) {
        }
    }
}
